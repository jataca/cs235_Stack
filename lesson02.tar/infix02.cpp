/***********************************************************************
 * Module:
 *    Lesson 02, Stack
 *    Brother Helfrich, CS 235
 * Author:
 *    <your name here>
 * Summary:
 *    This program will implement the testInfixToPostfix()
 *    and testInfixToAssembly() functions
 ************************************************************************/

#include <iostream>    // for ISTREAM and COUT
#include <string>      // for STRING
#include <cstring>
#include <cassert>     // for ASSERT
#include "stack.h"     // for STACK
//#include <stack>
using namespace std;

class token
{
public:
   int determineOrder(char input);
   bool isOperator(char input);
   string variableName(string &input);
private:
};

int token::determineOrder(char input)
{
   switch (input)
   {
      case '(':
         return 4;
         break;
      case ')':
         return 3;
         break;
      case '^':
         return 2;
         break;
      case '*':
      case '/':
      case '%':
         return 1;
         break;
      case '+':
      case '-':
         return 0;
         break;
      default:
         return 5;
   }
}

bool token::isOperator(char input)
{
   switch (input)
   {
      case '(':
      case ')':
      case '^':
      case '*':
      case '/':
      case '%':
      case '+':
      case '-':
        return true;
      break;
   default:
      return false;
   }
}

string token::variableName(string &input)
{
   string variable;
   while (input[0] != ' ' && input[0] != ')' && !input.empty())
   {
      variable += input[0];
      input.erase(0,1);
   }
   return variable;
}
   
/*****************************************************
 * CONVERT INFIX TO POSTFIX
 * Convert infix equation "5 + 2" into postifx "5 2 +"
 *****************************************************/
string convertInfixToPostfix(string & infix)
{
   string postfix;
   token tokenClass;
   Stack<char> theStack;
   while(infix.size() && infix != "quit")
   {
      if (infix[0] == ' ')
         infix.erase(0,1);

      else if(tokenClass.isOperator(infix[0]))
      {
         switch (tokenClass.determineOrder(infix[0]))
         {
            case 5:
               return (postfix = "Unrecognized operator: " + infix[0]);
            case 4:
               theStack.push(infix[0]);
               break;
            case 3:
               while (theStack.top() != '(')
               {
                 postfix += " ";
                 postfix += theStack.top();
                 theStack.pop();
               }
               theStack.pop();
               break;
            case 2:
               theStack.push(infix[0]);
               break;
            case 1:
            case 0:
               if (theStack.empty() || theStack.top() == '(' ||
                   tokenClass.determineOrder(infix[0]) > tokenClass.determineOrder(theStack.top()))
               {
                  theStack.push(infix[0]);
                  break;
               }
               else
               {
                  while (!theStack.empty() &&
                         tokenClass.determineOrder(infix[0]) <= tokenClass.determineOrder(theStack.top()))
                  {
                     postfix += " ";
                     postfix += theStack.top();
                     theStack.pop();
                  }
                  theStack.push(infix[0]);
                  infix.erase(0,1);
               }
         }
         infix[1] == ' ' ? infix.erase(0,2) : infix.erase(0,1);
      }
         
      else if (infix[1] != ' ' && infix[1] != ')' && infix.size() != 1)//named variable
      {
         postfix += " ";
         postfix += tokenClass.variableName(infix);
      }
         
      else //single char variable
      {
         postfix += " ";
         postfix += infix[0];
         infix[1] == ' ' ? infix.erase(0,2) : infix.erase(0,1);
      }
   }

   //Empty the stack
   while (infix.empty() && theStack.size())
   {
      if (theStack.top() == '(')               //If '(' is the only thing in the stack
         theStack.pop();
      else
      {
         postfix += " ";
         postfix += theStack.top();            //Retrieve and remove from stack
         theStack.pop();
      }
   }
   if (postfix[0] == ' ')
      postfix.erase(0,1);
   return postfix;
}

/*****************************************************
 * TEST INFIX TO POSTFIX
 * Prompt the user for infix text and display the
 * equivalent postfix expression
 *****************************************************/
int main()//void testInfixToPostfix()
{
   string input;
   cout << "Enter an infix equation.  Type \"quit\" when done.\n";
   
   do
   {
      // handle errors
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(256, '\n');
      }
      
      // prompt for infix
      cout << "infix > ";
      getline(cin, input);

      // generate postfix
      if (input != "quit")
      {
         string postfix = convertInfixToPostfix(input);
         cout << "\tpostfix: " << postfix << endl << endl;
      }
   }
   while (input != "quit");
}

/**********************************************
 * CONVERT POSTFIX TO ASSEMBLY
 * Convert postfix "5 2 +" to assembly:
 *     LOAD 5
 *     ADD 2
 *     STORE VALUE1
 **********************************************/
/*string convertPostfixToAssembly(const string & postfix)
{
   string assembly;

   return assembly;
}
*/
/*****************************************************
 * TEST INFIX TO ASSEMBLY
 * Prompt the user for infix text and display the
 * resulting assembly instructions
 *****************************************************/
/*void testInfixToAssembly()
{
   string input;
   cout << "Enter an infix equation.  Type \"quit\" when done.\n";

   do
   {
      // handle errors
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(256, '\n');
      }
      
      // prompt for infix
      cout << "infix > ";
      getline(cin, input);
      
      // generate postfix
      if (input != "quit")
      {
         string postfix = convertInfixToPostfix(input);
         cout << convertPostfixToAssembly(postfix);
      }
   }
   while (input != "quit");
      
}
*/
